$(function(){

    console.log('系统信息')

});
