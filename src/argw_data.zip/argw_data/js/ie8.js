// $('body').click(function (eve) {
//     if (
//         $(eve.target).parents('.modal-box').length <= 0
//     ) {
//         $('.modal-box').hide();
//     }
// });